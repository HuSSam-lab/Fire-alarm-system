﻿
namespace first_project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panelMenu = new System.Windows.Forms.Panel();
            this.iconButton1 = new FontAwesome.Sharp.IconButton();
            this.statusbutton = new FontAwesome.Sharp.IconButton();
            this.triggerbutton = new FontAwesome.Sharp.IconButton();
            this.stabilitybutton = new FontAwesome.Sharp.IconButton();
            this.onoffbutton = new FontAwesome.Sharp.IconButton();
            this.panelLogic = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.homeicon = new System.Windows.Forms.Label();
            this.iconcurrent = new FontAwesome.Sharp.IconPictureBox();
            this.panelShadow = new System.Windows.Forms.Panel();
            this.desktop = new System.Windows.Forms.Panel();
            this.iconPictureBox34 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox33 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox32 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox31 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox30 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox29 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox28 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox27 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox26 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox25 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox24 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox23 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox22 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox21 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox20 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox19 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox18 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox17 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox16 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox14 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox15 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox13 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox12 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox11 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox10 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox9 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox8 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox7 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox6 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox5 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox4 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox3 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox2 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            this.iconButton2 = new FontAwesome.Sharp.IconButton();
            this.panelMenu.SuspendLayout();
            this.panelLogic.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconcurrent)).BeginInit();
            this.desktop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.panelMenu.Controls.Add(this.iconButton1);
            this.panelMenu.Controls.Add(this.statusbutton);
            this.panelMenu.Controls.Add(this.triggerbutton);
            this.panelMenu.Controls.Add(this.stabilitybutton);
            this.panelMenu.Controls.Add(this.onoffbutton);
            this.panelMenu.Controls.Add(this.panelLogic);
            this.panelMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelMenu.Location = new System.Drawing.Point(0, 0);
            this.panelMenu.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(257, 644);
            this.panelMenu.TabIndex = 2;
            // 
            // iconButton1
            // 
            this.iconButton1.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconButton1.FlatAppearance.BorderSize = 0;
            this.iconButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton1.ForeColor = System.Drawing.Color.Gainsboro;
            this.iconButton1.IconChar = FontAwesome.Sharp.IconChar.InfoCircle;
            this.iconButton1.IconColor = System.Drawing.Color.White;
            this.iconButton1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton1.IconSize = 32;
            this.iconButton1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton1.Location = new System.Drawing.Point(0, 511);
            this.iconButton1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.iconButton1.Name = "iconButton1";
            this.iconButton1.Padding = new System.Windows.Forms.Padding(12, 0, 23, 0);
            this.iconButton1.Size = new System.Drawing.Size(257, 74);
            this.iconButton1.TabIndex = 9;
            this.iconButton1.Text = "About";
            this.iconButton1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButton1.UseVisualStyleBackColor = true;
            this.iconButton1.Click += new System.EventHandler(this.iconButton1_Click);
            // 
            // statusbutton
            // 
            this.statusbutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.statusbutton.FlatAppearance.BorderSize = 0;
            this.statusbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.statusbutton.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statusbutton.ForeColor = System.Drawing.Color.Gainsboro;
            this.statusbutton.IconChar = FontAwesome.Sharp.IconChar.Industry;
            this.statusbutton.IconColor = System.Drawing.Color.White;
            this.statusbutton.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.statusbutton.IconSize = 32;
            this.statusbutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.statusbutton.Location = new System.Drawing.Point(0, 437);
            this.statusbutton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.statusbutton.Name = "statusbutton";
            this.statusbutton.Padding = new System.Windows.Forms.Padding(12, 0, 23, 0);
            this.statusbutton.Size = new System.Drawing.Size(257, 74);
            this.statusbutton.TabIndex = 8;
            this.statusbutton.Text = "System Status";
            this.statusbutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.statusbutton.UseVisualStyleBackColor = true;
            this.statusbutton.Click += new System.EventHandler(this.statusbutton_Click);
            // 
            // triggerbutton
            // 
            this.triggerbutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.triggerbutton.FlatAppearance.BorderSize = 0;
            this.triggerbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.triggerbutton.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.triggerbutton.ForeColor = System.Drawing.Color.Gainsboro;
            this.triggerbutton.IconChar = FontAwesome.Sharp.IconChar.Bolt;
            this.triggerbutton.IconColor = System.Drawing.Color.White;
            this.triggerbutton.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.triggerbutton.IconSize = 32;
            this.triggerbutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.triggerbutton.Location = new System.Drawing.Point(0, 363);
            this.triggerbutton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.triggerbutton.Name = "triggerbutton";
            this.triggerbutton.Padding = new System.Windows.Forms.Padding(12, 0, 23, 0);
            this.triggerbutton.Size = new System.Drawing.Size(257, 74);
            this.triggerbutton.TabIndex = 7;
            this.triggerbutton.Text = "Fire Trigger";
            this.triggerbutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.triggerbutton.UseVisualStyleBackColor = true;
            this.triggerbutton.Click += new System.EventHandler(this.triggerbutton_Click);
            // 
            // stabilitybutton
            // 
            this.stabilitybutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.stabilitybutton.FlatAppearance.BorderSize = 0;
            this.stabilitybutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.stabilitybutton.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stabilitybutton.ForeColor = System.Drawing.Color.Gainsboro;
            this.stabilitybutton.IconChar = FontAwesome.Sharp.IconChar.CalendarCheck;
            this.stabilitybutton.IconColor = System.Drawing.Color.White;
            this.stabilitybutton.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.stabilitybutton.IconSize = 32;
            this.stabilitybutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stabilitybutton.Location = new System.Drawing.Point(0, 289);
            this.stabilitybutton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.stabilitybutton.Name = "stabilitybutton";
            this.stabilitybutton.Padding = new System.Windows.Forms.Padding(12, 0, 23, 0);
            this.stabilitybutton.Size = new System.Drawing.Size(257, 74);
            this.stabilitybutton.TabIndex = 4;
            this.stabilitybutton.Text = "Check Stability";
            this.stabilitybutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.stabilitybutton.UseVisualStyleBackColor = true;
            this.stabilitybutton.Click += new System.EventHandler(this.stabilitybutton_Click);
            // 
            // onoffbutton
            // 
            this.onoffbutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.onoffbutton.FlatAppearance.BorderSize = 0;
            this.onoffbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.onoffbutton.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.onoffbutton.ForeColor = System.Drawing.Color.Gainsboro;
            this.onoffbutton.IconChar = FontAwesome.Sharp.IconChar.Cogs;
            this.onoffbutton.IconColor = System.Drawing.Color.White;
            this.onoffbutton.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.onoffbutton.IconSize = 32;
            this.onoffbutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.onoffbutton.Location = new System.Drawing.Point(0, 215);
            this.onoffbutton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.onoffbutton.Name = "onoffbutton";
            this.onoffbutton.Padding = new System.Windows.Forms.Padding(12, 0, 23, 0);
            this.onoffbutton.Size = new System.Drawing.Size(257, 74);
            this.onoffbutton.TabIndex = 3;
            this.onoffbutton.Text = "Start System";
            this.onoffbutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.onoffbutton.UseVisualStyleBackColor = true;
            this.onoffbutton.Click += new System.EventHandler(this.onoffbutton_Click);
            // 
            // panelLogic
            // 
            this.panelLogic.Controls.Add(this.pictureBox1);
            this.panelLogic.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogic.Location = new System.Drawing.Point(0, 0);
            this.panelLogic.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelLogic.Name = "panelLogic";
            this.panelLogic.Size = new System.Drawing.Size(257, 215);
            this.panelLogic.TabIndex = 3;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(37, 15);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(203, 161);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(25)))), ((int)(((byte)(62)))));
            this.panel1.Controls.Add(this.homeicon);
            this.panel1.Controls.Add(this.iconcurrent);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(257, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(747, 92);
            this.panel1.TabIndex = 3;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            // 
            // homeicon
            // 
            this.homeicon.AutoSize = true;
            this.homeicon.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homeicon.ForeColor = System.Drawing.Color.Gainsboro;
            this.homeicon.Location = new System.Drawing.Point(68, 37);
            this.homeicon.Name = "homeicon";
            this.homeicon.Size = new System.Drawing.Size(53, 21);
            this.homeicon.TabIndex = 1;
            this.homeicon.Text = "Home";
            // 
            // iconcurrent
            // 
            this.iconcurrent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(25)))), ((int)(((byte)(62)))));
            this.iconcurrent.ForeColor = System.Drawing.Color.LavenderBlush;
            this.iconcurrent.IconChar = FontAwesome.Sharp.IconChar.Home;
            this.iconcurrent.IconColor = System.Drawing.Color.LavenderBlush;
            this.iconcurrent.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconcurrent.IconSize = 37;
            this.iconcurrent.Location = new System.Drawing.Point(29, 32);
            this.iconcurrent.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.iconcurrent.Name = "iconcurrent";
            this.iconcurrent.Size = new System.Drawing.Size(37, 39);
            this.iconcurrent.TabIndex = 0;
            this.iconcurrent.TabStop = false;
            // 
            // panelShadow
            // 
            this.panelShadow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(24)))), ((int)(((byte)(58)))));
            this.panelShadow.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelShadow.Location = new System.Drawing.Point(257, 92);
            this.panelShadow.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelShadow.Name = "panelShadow";
            this.panelShadow.Size = new System.Drawing.Size(747, 11);
            this.panelShadow.TabIndex = 4;
            // 
            // desktop
            // 
            this.desktop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.desktop.Controls.Add(this.iconPictureBox34);
            this.desktop.Controls.Add(this.iconPictureBox33);
            this.desktop.Controls.Add(this.iconPictureBox5);
            this.desktop.Controls.Add(this.iconPictureBox32);
            this.desktop.Controls.Add(this.iconPictureBox31);
            this.desktop.Controls.Add(this.iconPictureBox30);
            this.desktop.Controls.Add(this.iconPictureBox29);
            this.desktop.Controls.Add(this.iconPictureBox28);
            this.desktop.Controls.Add(this.iconPictureBox27);
            this.desktop.Controls.Add(this.iconPictureBox26);
            this.desktop.Controls.Add(this.iconPictureBox25);
            this.desktop.Controls.Add(this.iconPictureBox24);
            this.desktop.Controls.Add(this.iconPictureBox23);
            this.desktop.Controls.Add(this.iconPictureBox22);
            this.desktop.Controls.Add(this.iconPictureBox21);
            this.desktop.Controls.Add(this.iconPictureBox20);
            this.desktop.Controls.Add(this.iconPictureBox19);
            this.desktop.Controls.Add(this.iconPictureBox18);
            this.desktop.Controls.Add(this.iconPictureBox17);
            this.desktop.Controls.Add(this.iconPictureBox16);
            this.desktop.Controls.Add(this.iconPictureBox14);
            this.desktop.Controls.Add(this.iconPictureBox15);
            this.desktop.Controls.Add(this.iconPictureBox13);
            this.desktop.Controls.Add(this.iconPictureBox12);
            this.desktop.Controls.Add(this.iconPictureBox11);
            this.desktop.Controls.Add(this.iconPictureBox10);
            this.desktop.Controls.Add(this.iconPictureBox9);
            this.desktop.Controls.Add(this.iconPictureBox8);
            this.desktop.Controls.Add(this.iconPictureBox7);
            this.desktop.Controls.Add(this.iconPictureBox6);
            this.desktop.Controls.Add(this.iconPictureBox4);
            this.desktop.Controls.Add(this.iconPictureBox3);
            this.desktop.Controls.Add(this.iconPictureBox2);
            this.desktop.Controls.Add(this.iconPictureBox1);
            this.desktop.Controls.Add(this.iconButton2);
            this.desktop.Dock = System.Windows.Forms.DockStyle.Fill;
            this.desktop.Location = new System.Drawing.Point(257, 103);
            this.desktop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.desktop.Name = "desktop";
            this.desktop.Size = new System.Drawing.Size(747, 541);
            this.desktop.TabIndex = 5;
            // 
            // iconPictureBox34
            // 
            this.iconPictureBox34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox34.ForeColor = System.Drawing.Color.Black;
            this.iconPictureBox34.IconChar = FontAwesome.Sharp.IconChar.Nimblr;
            this.iconPictureBox34.IconColor = System.Drawing.Color.Black;
            this.iconPictureBox34.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox34.IconSize = 157;
            this.iconPictureBox34.Location = new System.Drawing.Point(220, 423);
            this.iconPictureBox34.Name = "iconPictureBox34";
            this.iconPictureBox34.Size = new System.Drawing.Size(157, 241);
            this.iconPictureBox34.TabIndex = 1;
            this.iconPictureBox34.TabStop = false;
            // 
            // iconPictureBox33
            // 
            this.iconPictureBox33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox33.ForeColor = System.Drawing.Color.Black;
            this.iconPictureBox33.IconChar = FontAwesome.Sharp.IconChar.MinusCircle;
            this.iconPictureBox33.IconColor = System.Drawing.Color.Black;
            this.iconPictureBox33.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox33.IconSize = 157;
            this.iconPictureBox33.Location = new System.Drawing.Point(233, 104);
            this.iconPictureBox33.Name = "iconPictureBox33";
            this.iconPictureBox33.Size = new System.Drawing.Size(157, 241);
            this.iconPictureBox33.TabIndex = 1;
            this.iconPictureBox33.TabStop = false;
            // 
            // iconPictureBox32
            // 
            this.iconPictureBox32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox32.ForeColor = System.Drawing.Color.Black;
            this.iconPictureBox32.IconChar = FontAwesome.Sharp.IconChar.Meh;
            this.iconPictureBox32.IconColor = System.Drawing.Color.Black;
            this.iconPictureBox32.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox32.IconSize = 157;
            this.iconPictureBox32.Location = new System.Drawing.Point(91, -42);
            this.iconPictureBox32.Name = "iconPictureBox32";
            this.iconPictureBox32.Size = new System.Drawing.Size(157, 241);
            this.iconPictureBox32.TabIndex = 1;
            this.iconPictureBox32.TabStop = false;
            // 
            // iconPictureBox31
            // 
            this.iconPictureBox31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox31.ForeColor = System.Drawing.Color.Black;
            this.iconPictureBox31.IconChar = FontAwesome.Sharp.IconChar.Medapps;
            this.iconPictureBox31.IconColor = System.Drawing.Color.Black;
            this.iconPictureBox31.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox31.IconSize = 157;
            this.iconPictureBox31.Location = new System.Drawing.Point(433, -71);
            this.iconPictureBox31.Name = "iconPictureBox31";
            this.iconPictureBox31.Size = new System.Drawing.Size(157, 241);
            this.iconPictureBox31.TabIndex = 1;
            this.iconPictureBox31.TabStop = false;
            this.iconPictureBox31.Click += new System.EventHandler(this.iconPictureBox31_Click);
            // 
            // iconPictureBox30
            // 
            this.iconPictureBox30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox30.ForeColor = System.Drawing.Color.Black;
            this.iconPictureBox30.IconChar = FontAwesome.Sharp.IconChar.Lock;
            this.iconPictureBox30.IconColor = System.Drawing.Color.Black;
            this.iconPictureBox30.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox30.IconSize = 157;
            this.iconPictureBox30.Location = new System.Drawing.Point(499, 288);
            this.iconPictureBox30.Name = "iconPictureBox30";
            this.iconPictureBox30.Size = new System.Drawing.Size(157, 241);
            this.iconPictureBox30.TabIndex = 1;
            this.iconPictureBox30.TabStop = false;
            // 
            // iconPictureBox29
            // 
            this.iconPictureBox29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox29.ForeColor = System.Drawing.Color.Black;
            this.iconPictureBox29.IconChar = FontAwesome.Sharp.IconChar.LockOpen;
            this.iconPictureBox29.IconColor = System.Drawing.Color.Black;
            this.iconPictureBox29.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox29.IconSize = 157;
            this.iconPictureBox29.Location = new System.Drawing.Point(57, -4);
            this.iconPictureBox29.Name = "iconPictureBox29";
            this.iconPictureBox29.Size = new System.Drawing.Size(157, 241);
            this.iconPictureBox29.TabIndex = 1;
            this.iconPictureBox29.TabStop = false;
            // 
            // iconPictureBox28
            // 
            this.iconPictureBox28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox28.ForeColor = System.Drawing.Color.Black;
            this.iconPictureBox28.IconChar = FontAwesome.Sharp.IconChar.Lightbulb;
            this.iconPictureBox28.IconColor = System.Drawing.Color.Black;
            this.iconPictureBox28.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox28.IconSize = 157;
            this.iconPictureBox28.Location = new System.Drawing.Point(182, 186);
            this.iconPictureBox28.Name = "iconPictureBox28";
            this.iconPictureBox28.Size = new System.Drawing.Size(157, 241);
            this.iconPictureBox28.TabIndex = 1;
            this.iconPictureBox28.TabStop = false;
            // 
            // iconPictureBox27
            // 
            this.iconPictureBox27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox27.ForeColor = System.Drawing.Color.Black;
            this.iconPictureBox27.IconChar = FontAwesome.Sharp.IconChar.Khanda;
            this.iconPictureBox27.IconColor = System.Drawing.Color.Black;
            this.iconPictureBox27.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox27.IconSize = 157;
            this.iconPictureBox27.Location = new System.Drawing.Point(208, 322);
            this.iconPictureBox27.Name = "iconPictureBox27";
            this.iconPictureBox27.Size = new System.Drawing.Size(157, 241);
            this.iconPictureBox27.TabIndex = 1;
            this.iconPictureBox27.TabStop = false;
            // 
            // iconPictureBox26
            // 
            this.iconPictureBox26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox26.ForeColor = System.Drawing.Color.Black;
            this.iconPictureBox26.IconChar = FontAwesome.Sharp.IconChar.JediOrder;
            this.iconPictureBox26.IconColor = System.Drawing.Color.Black;
            this.iconPictureBox26.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox26.IconSize = 157;
            this.iconPictureBox26.Location = new System.Drawing.Point(224, 123);
            this.iconPictureBox26.Name = "iconPictureBox26";
            this.iconPictureBox26.Size = new System.Drawing.Size(157, 241);
            this.iconPictureBox26.TabIndex = 1;
            this.iconPictureBox26.TabStop = false;
            // 
            // iconPictureBox25
            // 
            this.iconPictureBox25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox25.ForeColor = System.Drawing.Color.Black;
            this.iconPictureBox25.IconChar = FontAwesome.Sharp.IconChar.Info;
            this.iconPictureBox25.IconColor = System.Drawing.Color.Black;
            this.iconPictureBox25.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox25.IconSize = 157;
            this.iconPictureBox25.Location = new System.Drawing.Point(535, 56);
            this.iconPictureBox25.Name = "iconPictureBox25";
            this.iconPictureBox25.Size = new System.Drawing.Size(157, 241);
            this.iconPictureBox25.TabIndex = 1;
            this.iconPictureBox25.TabStop = false;
            this.iconPictureBox25.Click += new System.EventHandler(this.iconPictureBox25_Click);
            // 
            // iconPictureBox24
            // 
            this.iconPictureBox24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox24.ForeColor = System.Drawing.Color.Black;
            this.iconPictureBox24.IconChar = FontAwesome.Sharp.IconChar.HourglassHalf;
            this.iconPictureBox24.IconColor = System.Drawing.Color.Black;
            this.iconPictureBox24.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox24.IconSize = 157;
            this.iconPictureBox24.Location = new System.Drawing.Point(543, -4);
            this.iconPictureBox24.Name = "iconPictureBox24";
            this.iconPictureBox24.Size = new System.Drawing.Size(157, 241);
            this.iconPictureBox24.TabIndex = 1;
            this.iconPictureBox24.TabStop = false;
            // 
            // iconPictureBox23
            // 
            this.iconPictureBox23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox23.ForeColor = System.Drawing.Color.Black;
            this.iconPictureBox23.IconChar = FontAwesome.Sharp.IconChar.HourglassEnd;
            this.iconPictureBox23.IconColor = System.Drawing.Color.Black;
            this.iconPictureBox23.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox23.IconSize = 157;
            this.iconPictureBox23.Location = new System.Drawing.Point(543, 90);
            this.iconPictureBox23.Name = "iconPictureBox23";
            this.iconPictureBox23.Size = new System.Drawing.Size(157, 241);
            this.iconPictureBox23.TabIndex = 1;
            this.iconPictureBox23.TabStop = false;
            // 
            // iconPictureBox22
            // 
            this.iconPictureBox22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox22.ForeColor = System.Drawing.Color.Black;
            this.iconPictureBox22.IconChar = FontAwesome.Sharp.IconChar.Home;
            this.iconPictureBox22.IconColor = System.Drawing.Color.Black;
            this.iconPictureBox22.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox22.IconSize = 157;
            this.iconPictureBox22.Location = new System.Drawing.Point(270, 75);
            this.iconPictureBox22.Name = "iconPictureBox22";
            this.iconPictureBox22.Size = new System.Drawing.Size(157, 241);
            this.iconPictureBox22.TabIndex = 1;
            this.iconPictureBox22.TabStop = false;
            // 
            // iconPictureBox21
            // 
            this.iconPictureBox21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox21.ForeColor = System.Drawing.Color.Black;
            this.iconPictureBox21.IconChar = FontAwesome.Sharp.IconChar.Heartbeat;
            this.iconPictureBox21.IconColor = System.Drawing.Color.Black;
            this.iconPictureBox21.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox21.IconSize = 157;
            this.iconPictureBox21.Location = new System.Drawing.Point(254, -4);
            this.iconPictureBox21.Name = "iconPictureBox21";
            this.iconPictureBox21.Size = new System.Drawing.Size(157, 241);
            this.iconPictureBox21.TabIndex = 1;
            this.iconPictureBox21.TabStop = false;
            // 
            // iconPictureBox20
            // 
            this.iconPictureBox20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox20.ForeColor = System.Drawing.Color.Black;
            this.iconPictureBox20.IconChar = FontAwesome.Sharp.IconChar.HandsWash;
            this.iconPictureBox20.IconColor = System.Drawing.Color.Black;
            this.iconPictureBox20.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox20.IconSize = 157;
            this.iconPictureBox20.Location = new System.Drawing.Point(208, 176);
            this.iconPictureBox20.Name = "iconPictureBox20";
            this.iconPictureBox20.Size = new System.Drawing.Size(157, 241);
            this.iconPictureBox20.TabIndex = 1;
            this.iconPictureBox20.TabStop = false;
            // 
            // iconPictureBox19
            // 
            this.iconPictureBox19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox19.ForeColor = System.Drawing.Color.Black;
            this.iconPictureBox19.IconChar = FontAwesome.Sharp.IconChar.HandSparkles;
            this.iconPictureBox19.IconColor = System.Drawing.Color.Black;
            this.iconPictureBox19.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox19.IconSize = 157;
            this.iconPictureBox19.Location = new System.Drawing.Point(96, 56);
            this.iconPictureBox19.Name = "iconPictureBox19";
            this.iconPictureBox19.Size = new System.Drawing.Size(157, 241);
            this.iconPictureBox19.TabIndex = 1;
            this.iconPictureBox19.TabStop = false;
            // 
            // iconPictureBox18
            // 
            this.iconPictureBox18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox18.ForeColor = System.Drawing.Color.Black;
            this.iconPictureBox18.IconChar = FontAwesome.Sharp.IconChar.HandHoldingWater;
            this.iconPictureBox18.IconColor = System.Drawing.Color.Black;
            this.iconPictureBox18.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox18.IconSize = 157;
            this.iconPictureBox18.Location = new System.Drawing.Point(169, 153);
            this.iconPictureBox18.Name = "iconPictureBox18";
            this.iconPictureBox18.Size = new System.Drawing.Size(157, 241);
            this.iconPictureBox18.TabIndex = 1;
            this.iconPictureBox18.TabStop = false;
            // 
            // iconPictureBox17
            // 
            this.iconPictureBox17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox17.ForeColor = System.Drawing.Color.Black;
            this.iconPictureBox17.IconChar = FontAwesome.Sharp.IconChar.HandHoldingMedical;
            this.iconPictureBox17.IconColor = System.Drawing.Color.Black;
            this.iconPictureBox17.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox17.IconSize = 157;
            this.iconPictureBox17.Location = new System.Drawing.Point(387, 123);
            this.iconPictureBox17.Name = "iconPictureBox17";
            this.iconPictureBox17.Size = new System.Drawing.Size(157, 241);
            this.iconPictureBox17.TabIndex = 1;
            this.iconPictureBox17.TabStop = false;
            // 
            // iconPictureBox16
            // 
            this.iconPictureBox16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox16.ForeColor = System.Drawing.Color.Black;
            this.iconPictureBox16.IconChar = FontAwesome.Sharp.IconChar.HandHoldingHeart;
            this.iconPictureBox16.IconColor = System.Drawing.Color.Black;
            this.iconPictureBox16.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox16.IconSize = 157;
            this.iconPictureBox16.Location = new System.Drawing.Point(224, 38);
            this.iconPictureBox16.Name = "iconPictureBox16";
            this.iconPictureBox16.Size = new System.Drawing.Size(157, 241);
            this.iconPictureBox16.TabIndex = 1;
            this.iconPictureBox16.TabStop = false;
            // 
            // iconPictureBox14
            // 
            this.iconPictureBox14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox14.ForeColor = System.Drawing.Color.Black;
            this.iconPictureBox14.IconChar = FontAwesome.Sharp.IconChar.Grunt;
            this.iconPictureBox14.IconColor = System.Drawing.Color.Black;
            this.iconPictureBox14.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox14.IconSize = 157;
            this.iconPictureBox14.Location = new System.Drawing.Point(433, 75);
            this.iconPictureBox14.Name = "iconPictureBox14";
            this.iconPictureBox14.Size = new System.Drawing.Size(157, 241);
            this.iconPictureBox14.TabIndex = 1;
            this.iconPictureBox14.TabStop = false;
            // 
            // iconPictureBox15
            // 
            this.iconPictureBox15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox15.ForeColor = System.Drawing.Color.Black;
            this.iconPictureBox15.IconChar = FontAwesome.Sharp.IconChar.Gripfire;
            this.iconPictureBox15.IconColor = System.Drawing.Color.Black;
            this.iconPictureBox15.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox15.IconSize = 157;
            this.iconPictureBox15.Location = new System.Drawing.Point(91, 260);
            this.iconPictureBox15.Name = "iconPictureBox15";
            this.iconPictureBox15.Size = new System.Drawing.Size(157, 241);
            this.iconPictureBox15.TabIndex = 1;
            this.iconPictureBox15.TabStop = false;
            // 
            // iconPictureBox13
            // 
            this.iconPictureBox13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox13.ForeColor = System.Drawing.Color.Black;
            this.iconPictureBox13.IconChar = FontAwesome.Sharp.IconChar.GrinStars;
            this.iconPictureBox13.IconColor = System.Drawing.Color.Black;
            this.iconPictureBox13.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox13.IconSize = 157;
            this.iconPictureBox13.Location = new System.Drawing.Point(471, 16);
            this.iconPictureBox13.Name = "iconPictureBox13";
            this.iconPictureBox13.Size = new System.Drawing.Size(157, 241);
            this.iconPictureBox13.TabIndex = 1;
            this.iconPictureBox13.TabStop = false;
            // 
            // iconPictureBox12
            // 
            this.iconPictureBox12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox12.ForeColor = System.Drawing.Color.Black;
            this.iconPictureBox12.IconChar = FontAwesome.Sharp.IconChar.GrinHearts;
            this.iconPictureBox12.IconColor = System.Drawing.Color.Black;
            this.iconPictureBox12.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox12.IconSize = 157;
            this.iconPictureBox12.Location = new System.Drawing.Point(270, 93);
            this.iconPictureBox12.Name = "iconPictureBox12";
            this.iconPictureBox12.Size = new System.Drawing.Size(157, 241);
            this.iconPictureBox12.TabIndex = 1;
            this.iconPictureBox12.TabStop = false;
            // 
            // iconPictureBox11
            // 
            this.iconPictureBox11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox11.ForeColor = System.Drawing.Color.Black;
            this.iconPictureBox11.IconChar = FontAwesome.Sharp.IconChar.GrinBeam;
            this.iconPictureBox11.IconColor = System.Drawing.Color.Black;
            this.iconPictureBox11.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox11.IconSize = 157;
            this.iconPictureBox11.Location = new System.Drawing.Point(19, 188);
            this.iconPictureBox11.Name = "iconPictureBox11";
            this.iconPictureBox11.Size = new System.Drawing.Size(157, 241);
            this.iconPictureBox11.TabIndex = 1;
            this.iconPictureBox11.TabStop = false;
            // 
            // iconPictureBox10
            // 
            this.iconPictureBox10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox10.ForeColor = System.Drawing.Color.Black;
            this.iconPictureBox10.IconChar = FontAwesome.Sharp.IconChar.Grin;
            this.iconPictureBox10.IconColor = System.Drawing.Color.Black;
            this.iconPictureBox10.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox10.IconSize = 157;
            this.iconPictureBox10.Location = new System.Drawing.Point(182, 93);
            this.iconPictureBox10.Name = "iconPictureBox10";
            this.iconPictureBox10.Size = new System.Drawing.Size(157, 241);
            this.iconPictureBox10.TabIndex = 1;
            this.iconPictureBox10.TabStop = false;
            // 
            // iconPictureBox9
            // 
            this.iconPictureBox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox9.ForeColor = System.Drawing.Color.Black;
            this.iconPictureBox9.IconChar = FontAwesome.Sharp.IconChar.GetPocket;
            this.iconPictureBox9.IconColor = System.Drawing.Color.Black;
            this.iconPictureBox9.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox9.IconSize = 157;
            this.iconPictureBox9.Location = new System.Drawing.Point(29, -25);
            this.iconPictureBox9.Name = "iconPictureBox9";
            this.iconPictureBox9.Size = new System.Drawing.Size(157, 241);
            this.iconPictureBox9.TabIndex = 1;
            this.iconPictureBox9.TabStop = false;
            // 
            // iconPictureBox8
            // 
            this.iconPictureBox8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox8.ForeColor = System.Drawing.Color.Black;
            this.iconPictureBox8.IconChar = FontAwesome.Sharp.IconChar.GasPump;
            this.iconPictureBox8.IconColor = System.Drawing.Color.Black;
            this.iconPictureBox8.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox8.IconSize = 157;
            this.iconPictureBox8.Location = new System.Drawing.Point(57, -3);
            this.iconPictureBox8.Name = "iconPictureBox8";
            this.iconPictureBox8.Size = new System.Drawing.Size(157, 241);
            this.iconPictureBox8.TabIndex = 1;
            this.iconPictureBox8.TabStop = false;
            this.iconPictureBox8.Click += new System.EventHandler(this.iconPictureBox8_Click);
            // 
            // iconPictureBox7
            // 
            this.iconPictureBox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox7.ForeColor = System.Drawing.Color.Red;
            this.iconPictureBox7.IconChar = FontAwesome.Sharp.IconChar.Flushed;
            this.iconPictureBox7.IconColor = System.Drawing.Color.Red;
            this.iconPictureBox7.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox7.IconSize = 157;
            this.iconPictureBox7.Location = new System.Drawing.Point(499, 123);
            this.iconPictureBox7.Name = "iconPictureBox7";
            this.iconPictureBox7.Size = new System.Drawing.Size(157, 241);
            this.iconPictureBox7.TabIndex = 1;
            this.iconPictureBox7.TabStop = false;
            // 
            // iconPictureBox6
            // 
            this.iconPictureBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox6.ForeColor = System.Drawing.Color.Red;
            this.iconPictureBox6.IconChar = FontAwesome.Sharp.IconChar.FirstOrderAlt;
            this.iconPictureBox6.IconColor = System.Drawing.Color.Red;
            this.iconPictureBox6.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox6.IconSize = 72;
            this.iconPictureBox6.Location = new System.Drawing.Point(662, 337);
            this.iconPictureBox6.Name = "iconPictureBox6";
            this.iconPictureBox6.Size = new System.Drawing.Size(72, 80);
            this.iconPictureBox6.TabIndex = 1;
            this.iconPictureBox6.TabStop = false;
            // 
            // iconPictureBox5
            // 
            this.iconPictureBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox5.IconChar = FontAwesome.Sharp.IconChar.FireAlt;
            this.iconPictureBox5.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox5.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox5.IconSize = 181;
            this.iconPictureBox5.Location = new System.Drawing.Point(57, 123);
            this.iconPictureBox5.Name = "iconPictureBox5";
            this.iconPictureBox5.Size = new System.Drawing.Size(181, 222);
            this.iconPictureBox5.TabIndex = 1;
            this.iconPictureBox5.TabStop = false;
            // 
            // iconPictureBox4
            // 
            this.iconPictureBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox4.IconChar = FontAwesome.Sharp.IconChar.FireExtinguisher;
            this.iconPictureBox4.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox4.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox4.IconSize = 181;
            this.iconPictureBox4.Location = new System.Drawing.Point(519, 75);
            this.iconPictureBox4.Name = "iconPictureBox4";
            this.iconPictureBox4.Size = new System.Drawing.Size(181, 222);
            this.iconPictureBox4.TabIndex = 1;
            this.iconPictureBox4.TabStop = false;
            // 
            // iconPictureBox3
            // 
            this.iconPictureBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox3.IconChar = FontAwesome.Sharp.IconChar.ExclamationTriangle;
            this.iconPictureBox3.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox3.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox3.IconSize = 181;
            this.iconPictureBox3.Location = new System.Drawing.Point(220, 38);
            this.iconPictureBox3.Name = "iconPictureBox3";
            this.iconPictureBox3.Size = new System.Drawing.Size(181, 222);
            this.iconPictureBox3.TabIndex = 1;
            this.iconPictureBox3.TabStop = false;
            // 
            // iconPictureBox2
            // 
            this.iconPictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox2.IconChar = FontAwesome.Sharp.IconChar.SadTear;
            this.iconPictureBox2.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox2.IconSize = 181;
            this.iconPictureBox2.Location = new System.Drawing.Point(107, 207);
            this.iconPictureBox2.Name = "iconPictureBox2";
            this.iconPictureBox2.Size = new System.Drawing.Size(181, 222);
            this.iconPictureBox2.TabIndex = 1;
            this.iconPictureBox2.TabStop = false;
            // 
            // iconPictureBox1
            // 
            this.iconPictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconPictureBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.Frown;
            this.iconPictureBox1.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox1.IconSize = 36;
            this.iconPictureBox1.Location = new System.Drawing.Point(127, 153);
            this.iconPictureBox1.Name = "iconPictureBox1";
            this.iconPictureBox1.Size = new System.Drawing.Size(36, 48);
            this.iconPictureBox1.TabIndex = 1;
            this.iconPictureBox1.TabStop = false;
            // 
            // iconButton2
            // 
            this.iconButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.iconButton2.BackgroundImage = global::first_project.Properties.Resources.png_clipart_fire_alarm_system_computer_icons_fire_protection_alarm_device_fire_monochrome_fire_alarm;
            this.iconButton2.Flip = FontAwesome.Sharp.FlipOrientation.Horizontal;
            this.iconButton2.IconChar = FontAwesome.Sharp.IconChar.None;
            this.iconButton2.IconColor = System.Drawing.Color.Black;
            this.iconButton2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton2.Location = new System.Drawing.Point(462, 186);
            this.iconButton2.Name = "iconButton2";
            this.iconButton2.Size = new System.Drawing.Size(67, 52);
            this.iconButton2.TabIndex = 0;
            this.iconButton2.Text = "iconButton2";
            this.iconButton2.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1004, 644);
            this.Controls.Add(this.desktop);
            this.Controls.Add(this.panelShadow);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panelMenu.ResumeLayout(false);
            this.panelLogic.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconcurrent)).EndInit();
            this.desktop.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelMenu;
        private FontAwesome.Sharp.IconButton statusbutton;
        private FontAwesome.Sharp.IconButton triggerbutton;
        private FontAwesome.Sharp.IconButton stabilitybutton;
        private FontAwesome.Sharp.IconButton onoffbutton;
        private System.Windows.Forms.Panel panelLogic;
        private FontAwesome.Sharp.IconButton iconButton1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private FontAwesome.Sharp.IconPictureBox iconcurrent;
        private System.Windows.Forms.Label homeicon;
        private System.Windows.Forms.Panel panelShadow;
        private System.Windows.Forms.Panel desktop;
        private FontAwesome.Sharp.IconButton iconButton2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox34;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox33;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox32;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox31;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox30;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox29;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox28;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox27;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox26;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox25;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox24;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox23;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox22;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox21;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox20;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox19;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox18;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox17;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox16;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox14;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox15;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox13;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox12;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox11;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox10;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox9;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox8;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox7;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox6;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox5;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox4;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox3;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
    }
}

