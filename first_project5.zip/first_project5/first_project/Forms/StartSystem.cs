﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace first_project.Forms
{
    public partial class StartSystem : Form
    {
        public StartSystem()
        {
            InitializeComponent();
        }


        public string rann() {

            Random rnd = new Random();
            int num = rnd.Next(3);
            if (num <= 1) return "1";
            else return "2";
        }
        private void button1_Click(object sender, EventArgs e)
        {
            //Console.WriteLine(rann());
            shared sh = new shared();
            sh.set_tank(rann());
           

        }
    }
}
