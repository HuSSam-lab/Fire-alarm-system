﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace first_project.Forms
{
    class shared
    {
        static string S_tankemptysensor ="0",S_tankfullsendorP="0";
        public void set_tank(string s) {
            S_tankemptysensor = s;
        }
        public string get_tank() { return S_tankemptysensor; }


    }
}
