﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace first_project.Forms
{
    public partial class SystemStatus : Form
    {
        shared sh = new shared();
        public SystemStatus()
        {
            InitializeComponent();
            label2.Text = sh.get_tank();
        }

        private void lxLedControl2_Click(object sender, EventArgs e)
        {

        }

        private void iconPictureBox32_Click(object sender, EventArgs e)
        {

        }

        private void iconPictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void SystemStatus_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
